Logout_Page()
{
	//Logout current session
	lr_start_transaction("S1_B2B_60_Logout");
	web_custom_request("web_custom_request2",
		    "URL=https://petstore.swagger.io/v2/user/logout",
			"Method=GET",
			"TargetFrame=",
			"Resource=0",
			"Referer=",
			LAST);
	lr_end_transaction("S1_B2B_60_Logout", LR_AUTO);

	return 0;
}

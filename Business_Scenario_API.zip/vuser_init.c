/*************************************************************************************************************
The following script will attempt to complete the following activities:
1. Create a new user, using randomly generated names.
2. Login to the system.
3. Load all available products, select a random one and view it.
4. Place an order for the product selected in step 3.
5. Search and load the purchase order and confirm it is the same as the order created.
6. Logout.

All requests timing are captured within the given transactions.

04/05/2022	Marius Brecher	Initialy created.

**************************************************************************************************************/
vuser_init()
{	
	return 0;
}

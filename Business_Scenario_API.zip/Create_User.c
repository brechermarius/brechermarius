Create_User()
{
	web_add_auto_header("wowapi-key","special-key");
	web_add_auto_header("Content-Type","application/json");	
	
	//Generate random names
	GenerateNames();
	
	web_reg_save_param_json("ParamName=P_StatusCode", "QueryString=$.code", SEARCH_FILTERS, "Notfound=warning", LAST);
	web_reg_save_param_json("ParamName=P_StatusMessage", "QueryString=$.message", SEARCH_FILTERS, "Notfound=warning", LAST);
	
	lr_start_transaction("S1_B2B_10_CreateUser");
	web_custom_request("web_custom_request",
		"URL=https://petstore.swagger.io/v2/user",
		"Method=POST",
		"TargetFrame=",
		"Resource=0",
		"Referer=",
		"Body={\r\n"
  			" \"id\": 0, \r\n"
			" \"username\": \"Admin\", \r\n"
			" \"firstName\": \"{P_FirstName}\", \r\n"
			" \"lastName\": \"{P_LastName}\", \r\n"
			" \"email\": \"{P_Email}\", \r\n"
			" \"password\": \"Admin\", \r\n"
			" \"phone\": \"0400000000\", \r\n"
			" \"userStatus\": 0 \r\n"
		"}",
		LAST);		
	
	if(strcmp(lr_eval_string("{P_StatusCode}"), "200") == 0 && atoi(lr_eval_string("{P_StatusMessage}")) > 0)
	{		
		lr_end_transaction("S1_B2B_10_CreateUser", LR_AUTO);
		lr_output_message(lr_eval_string("The user \"Admin\", was successfully created with ID: {P_StatusMessage}"));
	}
	else
	{
		lr_end_transaction("S1_B2B_10_CreateUser",LR_FAIL);
		lr_error_message("Failed to create user!!!");
		//lr_exit(LR_EXIT_ITERATION_AND_CONTINUE,LR_FAIL);
	}

	
	return 0;
}

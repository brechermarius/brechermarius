User_Login()
{
	web_reg_save_param_json("ParamName=P_LoginStatus", "QueryString=$.code", SEARCH_FILTERS, "Notfound=warning", LAST);
	web_reg_save_param_json("ParamName=P_LoginMessage", "QueryString=$.message", SEARCH_FILTERS, "Notfound=warning", LAST);
	
	lr_start_transaction("S1_B2B_20_UserLogin");
	web_custom_request("web_custom_request",
		    "URL=https://petstore.swagger.io/v2/user/login?username=Admin&password=Admin",
			"Method=GET",
			"TargetFrame=",
			"Resource=0",
			"Referer=",
			LAST);
	
	if(strcmp(lr_eval_string("{P_LoginStatus}"), "200") == 0)	
	{		
		lr_end_transaction("S1_B2B_20_UserLogin", LR_AUTO);
		lr_output_message(lr_eval_string("The user \"Admin\", has successfuly {P_LoginMessage}"));
	}
	else
	{
		lr_end_transaction("S1_B2B_20_UserLogin",LR_FAIL);
		lr_error_message("PET failed to be added to Store");
		lr_exit(LR_EXIT_ITERATION_AND_CONTINUE,LR_FAIL);
	}
	
	return 0;
}

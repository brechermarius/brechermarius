GenerateNames()
{
	char buff[32] = "";
	int x;

	srand(time(NULL)); //Has to be executed before using the rand() function
	//Generate Random First name
    for (x = 0; x < rand() % 4+4; x++)
	{   
		buff[x] = (char)atoi(lr_eval_string("{rNumber1}"));
	}
	lr_save_string(buff, "P_FirstName");	
	memset(buff, 0, sizeof(buff)); //clear the char

	srand(time(NULL)); //Has to be executed before using the rand() function
	//Generate Random Last name
    for (x = 0; x < rand() % 4+4; x++)
	{   
		buff[x] = (char)atoi(lr_eval_string("{rNumber1}"));
	}
	lr_save_string(buff, "P_LastName");	
	memset(buff, 0, sizeof(buff)); //clear the char

	//Generate Random email extension
    for (x = 0; x < 4; x++)
	{   
		buff[x] = (char)atoi(lr_eval_string("{rNumber1}"));
	}
	lr_save_string(buff, "TempEmail");	
	lr_save_string(lr_eval_string("{P_FirstName}.{P_LastName}@Test{TempEmail}.com.au"), "P_Email");	
	memset(buff, 0, sizeof(buff)); //clear the char
	
	return 0;
}

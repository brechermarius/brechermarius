Search_Product()
{
	//Find all available pets
	
	//{"id":9223372000001084263,"category":{"id":0,"name":"string"},"name":"fish"
	web_reg_save_param_ex("ParamName=C_AvailablePets", "LB={\"id\":", "RB=,\"category\":{", "Ordinal=all", "NotFound=warning", LAST);
	
	web_custom_request("web_custom_request2",
		    "URL=https://petstore.swagger.io/v2/pet/findByStatus?status=available",
			"Method=GET",
			"TargetFrame=",
			"Resource=0",
			"Referer=",
			LAST);
	
		
	//Select a random pet id
	lr_save_string(lr_paramarr_random("C_AvailablePets"), "PetID");
	
	web_reg_save_param_json("ParamName=C_Selected_PetID", "QueryString=$.id", SEARCH_FILTERS, "Notfound=warning", LAST);
	web_reg_save_param_json("ParamName=C_PetName", "QueryString=$.name", SEARCH_FILTERS, "Notfound=warning", LAST);
	
	//View a pet by given ID
	lr_start_transaction("S1_B2B_30_GetProduct");
	web_custom_request("web_custom_request3",
		    "URL=https://petstore.swagger.io/v2/pet/{PetID}",
			"Method=GET",
			"TargetFrame=",
			"Resource=0",
			"Referer=",
			LAST);	
	
	if(atol(lr_eval_string("{C_Selected_PetID}")) > 0)
	{		
		lr_end_transaction("S1_B2B_30_GetProduct", LR_AUTO);
		lr_output_message(lr_eval_string("The {C_PetName} with Pet ID: {C_Selected_PetID}, was searched and found."));
	}
	else
	{
		lr_end_transaction("S1_B2B_30_GetProduct",LR_FAIL);
		lr_error_message("Failed to find product!!!");
		//lr_exit(LR_EXIT_ITERATION_AND_CONTINUE,LR_FAIL);
	}
	
	return 0;
}

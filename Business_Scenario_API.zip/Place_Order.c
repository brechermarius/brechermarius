Place_Order()
{
	//Place a new order
	web_add_auto_header("wowapi-key","special-key");
	web_add_auto_header("Content-Type","application/json");	
	
	web_reg_save_param_json("ParamName=P_OrderID", "QueryString=$.id", SEARCH_FILTERS, "Notfound=warning", LAST);
	
	lr_start_transaction("S1_B2B_40_PlaceOrder");
	web_custom_request("web_custom_request4",
		"URL=https://petstore.swagger.io/v2/store/order",
		"Method=POST",
		"TargetFrame=",
		"Resource=0",
		"Referer=",
		"Body={\r\n"
		"  \"id\": 0,\r\n"
		"  \"petId\": {C_Selected_PetID},\r\n"
		"  \"quantity\": 1,\r\n"
		"  \"shipDate\": \"{P_ShipDate}\",\r\n"
		"  \"status\": \"placed\",\r\n"
		"  \"complete\": true\r\n"
		"}",
		LAST);	
	
	if(atol(lr_eval_string("{P_OrderID}")) > 0)
	{		
		lr_end_transaction("S1_B2B_40_PlaceOrder", LR_AUTO);
		lr_output_message(lr_eval_string("New order with Order ID: {P_OrderID} has been created successfuly."));
	}
	else
	{
		lr_end_transaction("S1_B2B_40_PlaceOrder",LR_FAIL);
		lr_error_message("Failed to create order!!!");
		//lr_exit(LR_EXIT_ITERATION_AND_CONTINUE,LR_FAIL);
	}
	
	//View purchase order by ID	
	web_reg_save_param_json("ParamName=P_FindOrderID", "QueryString=$.id", SEARCH_FILTERS, "Notfound=warning", LAST);
	
	lr_start_transaction("S1_B2B_50_FindOrder");
	web_custom_request("web_custom_request5",
		    "URL=https://petstore.swagger.io/v2/store/order/{P_OrderID}",
			"Method=GET",
			"TargetFrame=",
			"Resource=0",
			"Referer=",
			LAST);	
	
	if(strcmp(lr_eval_string("{P_OrderID}"), lr_eval_string("{P_FindOrderID}")) == 0)
	{		
		lr_end_transaction("S1_B2B_50_FindOrder", LR_AUTO);
		lr_output_message(lr_eval_string("Newly created order: {P_OrderID} was found successfuly."));
	}
	else
	{
		lr_end_transaction("S1_B2B_50_FindOrder",LR_FAIL);
		lr_error_message("Failed to find order!!!");
		//lr_exit(LR_EXIT_ITERATION_AND_CONTINUE,LR_FAIL);
	}
	
	return 0;
}

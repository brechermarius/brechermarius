/*************************************************************************************************************
The following script will attempt to add 20 new pts to a store, using the given API URL.
The script will total the transaction times and then average them by dividing the total time by the number
requests made. 
The test is designed to error and fail when the following conditions occur:
1. Average transaction time (of all transactions) is higher then 0.3 sec.
2. There are more then 1 failed POST requests.

**************************************************************************************************************/
vuser_init()
{
	lr_save_int(0, "C_PetID");
	
	return 0;
}

Post_request()
{
	int Total_Pets = 20;
	int faild_requests = 0;
	long i;
	double trans_time,avg_trans_time;
	
	web_add_auto_header("wowapi-key","special-key");
	web_add_auto_header("Content-Type","application/json");	
	
	//Submit the POST request n times to add new pets to store
	for(i=0; i<Total_Pets; i++)
	{		
		lr_save_string(lr_eval_string("{P_PetName}"), "C_PetName");
		web_reg_save_param_json("ParamName=P_PetID", "QueryString=$.id", SEARCH_FILTERS, "Notfound=warning", LAST);
		
		lr_start_transaction("S1_B2B_10_CreatePET");
		web_custom_request("web_custom_request",
		    "URL=https://petstore.swagger.io/v2/pet",
			"Method=POST",
			"TargetFrame=",
			"Resource=0",
			"Referer=",
			"Body={\r\n"
			"  \"id\": {C_PetID},\r\n"
			"  \"category\": {\r\n"
			"       \"id\": 0, \r\n"
			"       \"name\": \"PET\"\r\n\t},\r\n"
			"  \"name\": \"{C_PetName}\",\r\n"
			"  \"photoUrls\": [\"string\"],\r\n"
			"  \"status\": \"available\"\r\n"
			"}",
			LAST);
					
		//Constarct a unique ID.
		lr_save_int(i, "C_Ind");
		lr_save_string(lr_eval_string("{P_Pet_ID}{P_Pet_ID}{C_Ind}"), "C_PetID");
		
		if(strcmp(lr_eval_string("{P_PetID}"), "") == 0)	
		{		
			trans_time=trans_time+lr_get_transaction_duration("S1_B2B_10_CreatePET");
			lr_end_transaction("S1_B2B_10_CreatePET",LR_FAIL);
			lr_error_message("PET failed to be added to Store");
			faild_requests+=1;
			if(faild_requests > 1)
			{
				lr_error_message("Test failed due to more then 1 unseccussful requests!!! - %d",faild_requests);
				lr_exit(LR_EXIT_ITERATION_AND_CONTINUE,LR_FAIL);				
			}
		}
	    else
	    {
		    trans_time=trans_time+lr_get_transaction_duration("S1_B2B_10_CreatePET");
		    lr_end_transaction("S1_B2B_10_CreatePET", LR_AUTO);
			lr_output_message(lr_eval_string("PET {C_PetName} with ID: {C_PetID} was added to store successfully"));
	    }
	}
    
	//Calculating the average transaction times by dividing the total by n POST requests
	avg_trans_time=trans_time/Total_Pets;
	if(avg_trans_time > 0.3)
	{
		lr_error_message("Test FAILED with average transaction time of: %f",avg_trans_time);
	}
	else
	{
		lr_output_message("Test PASSED with average transaction time of: %f",avg_trans_time);
	}
	
	return 0;
}
